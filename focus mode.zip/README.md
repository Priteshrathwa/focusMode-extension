# Focus Mode Extension

A cross-browser extension that helps you stay focused by blocking distracting websites during timed focus sessions.

## Features

- ⏰ **Timer-based Focus Sessions** - Set custom timer durations (hours and minutes)
- 🚫 **Website Blocking** - Add custom websites to block during focus mode
- 📱 **Social Media Blocker** - Quick button to block all major social media sites
- 🔒 **Strict Mode** - Prevents early termination of focus sessions
- 💬 **Motivational Quotes** - Displays inspiring quotes on blocked pages
- 🎨 **Beautiful UI** - Modern, clean interface with circular timer display

## Browser Compatibility

This extension is compatible with:
- ✅ **Microsoft Edge** (Chromium-based)
- ✅ **Mozilla Firefox**
- ✅ **Google Chrome** (should work but not tested)

## Installation

### Microsoft Edge

1. Open Microsoft Edge
2. Navigate to `edge://extensions/`
3. Enable "Developer mode" in the left sidebar
4. Click "Load unpacked"
5. Select the folder containing the extension files
6. The extension should now appear in your extensions list

### Mozilla Firefox

1. Open Firefox
2. Navigate to `about:debugging`
3. Click "This Firefox" in the left sidebar
4. Click "Load Temporary Add-on"
5. Select the `manifest.json` file from the extension folder
6. The extension will be loaded temporarily (until Firefox restarts)

**For permanent installation in Firefox:**
1. Zip the entire extension folder
2. Rename the zip file to have a `.xpi` extension
3. Drag and drop the `.xpi` file into Firefox

### Google Chrome

1. Open Google Chrome
2. Navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked"
5. Select the folder containing the extension files

## Usage

1. **Adding Sites to Block:**
   - Click the extension icon in your browser toolbar
   - Enter a website URL (e.g., "youtube.com") in the input field
   - Click "Add" to add it to your blocked sites list
   - Use "Block All Social Media" for quick setup

2. **Starting a Focus Session:**
   - Set your desired timer duration (hours and minutes)
   - Optionally enable "Strict Mode" to prevent early termination
   - Click "Start Focus Mode"
   - Blocked sites will redirect to a motivational blocking page

3. **Stopping a Focus Session:**
   - Click "Stop Focus Mode" (disabled in Strict Mode)
   - Or wait for the timer to naturally expire

## Technical Details

### Manifest Version
- Uses Manifest V3 for better performance and security
- Cross-browser compatibility layer for Firefox support

### Permissions Required
- `storage` - Save blocked sites and timer settings
- `tabs` - Manage tab redirections and restoration
- `declarativeNetRequest` - Block network requests
- `activeTab` - Access current tab information
- `<all_urls>` - Required for content script injection

### Files Structure
```
├── manifest.json       # Extension configuration
├── background.js       # Service worker for timer management
├── popup.html          # Extension popup interface
├── popup.js           # Popup functionality
├── content.js         # Content script for site blocking
├── blocked.html       # Blocked page template
├── blocked.js         # Blocked page functionality
├── style.css          # Additional styling
├── rules.json         # Dynamic blocking rules storage
└── icon.png          # Extension icon
```

## Development

The extension uses a cross-browser compatibility layer:

```javascript
// Detects browser and uses appropriate API
const browserAPI = typeof chrome !== 'undefined' ? chrome : browser;
```

This allows the same code to work in both Chrome-based browsers (Edge, Chrome) and Firefox.

## Privacy

This extension:
- ✅ Stores all data locally (no cloud storage)
- ✅ Does not collect or transmit personal data
- ✅ Only accesses tabs when focus mode is active
- ✅ Open source and transparent

## License

This project is open source. Feel free to modify and distribute according to your needs.

## Support

If you encounter any issues:
1. Check that you have the latest version
2. Ensure all permissions are granted
3. Try reloading the extension
4. Check browser console for error messages

## Contributing

Contributions are welcome! Please ensure:
- Code works in both Edge and Firefox
- Follows the existing code style
- Updates this README if needed
