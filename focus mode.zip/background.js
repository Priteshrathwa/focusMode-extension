// Cross-browser compatibility: Edge uses chrome, Firefox uses browser
const browserAPI = typeof chrome !== 'undefined' ? chrome : browser;

let timerCheckInterval = null;

function checkFocusTimer() {
  browserAPI.storage.local.get(["focusMode", "timerStart", "timerDuration", "strictMode"]).then(data => {
    if (data.focusMode && data.timerStart && data.timerDuration) {
      const timerEnd = data.timerStart + data.timerDuration;
      if (Date.now() >= timerEnd) {
        // Stop focus mode
        browserAPI.storage.local.set({ focusMode: false, timerStart: null, timerDuration: null, strictMode: false });

        // Restore original URLs
        browserAPI.tabs.query({}).then(tabs => {
          tabs.forEach(tab => {
            if (tab.url.includes("blocked.html")) {
              browserAPI.storage.local.get("original_" + tab.id).then(data => {
                const url = data["original_" + tab.id];
                if (url) {
                  browserAPI.tabs.update(tab.id, { url: url });
                  browserAPI.storage.local.remove("original_" + tab.id);
                }
              });
            }
          });
        });
      }
    }
  });
}

// Restore state on startup
browserAPI.runtime.onStartup.addListener(() => {
  browserAPI.storage.local.set({ focusMode: false, timerStart: null, timerDuration: null, strictMode: false });

  browserAPI.tabs.query({}).then(tabs => {
    tabs.forEach(tab => {
      if (tab.url.includes("blocked.html")) {
        browserAPI.storage.local.get("original_" + tab.id).then(data => {
          const url = data["original_" + tab.id];
          if (url) {
            browserAPI.tabs.update(tab.id, { url: url });
            browserAPI.storage.local.remove("original_" + tab.id);
          }
        });
      }
    });
  });

  if (timerCheckInterval) clearInterval(timerCheckInterval);
  timerCheckInterval = setInterval(checkFocusTimer, 1000);
});

// Start timer check on install too
browserAPI.runtime.onInstalled.addListener(() => {
  if (timerCheckInterval) clearInterval(timerCheckInterval);
  timerCheckInterval = setInterval(checkFocusTimer, 1000);
});
