// Cross-browser compatibility: Edge uses chrome, Firefox uses browser
const browserAPI = typeof chrome !== 'undefined' ? chrome : browser;

(async () => {
  const { focusMode, blockedSites } = await browserAPI.storage.local.get(["focusMode", "blockedSites"]);
  if (!focusMode) return;

  const currentUrl = window.location.href;

  const shouldBlock = blockedSites?.some(site =>
    new RegExp(`://(.*\\.)?${site.replace('.', '\\.')}`).test(currentUrl)
  );

  if (shouldBlock && !window.location.href.includes("blocked.html")) {
    window.location.href = browserAPI.runtime.getURL("blocked.html");
  }
})();
